// Nội dung multiBot.js nên được thêm từ script bạn đã tạo trước đó
